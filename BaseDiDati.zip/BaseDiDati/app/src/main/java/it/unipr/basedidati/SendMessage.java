package it.unipr.basedidati;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.text.format.Formatter;
import android.text.style.LineBackgroundSpan;

import java.nio.channels.AsynchronousChannelGroup;

import static android.content.Context.WIFI_SERVICE;

public class SendMessage extends AsyncTask<String, Void, Void> {
    private Exception exception;
    private Socket socket = null;

    @Override
    protected Void doInBackground(String...params){
        try{
            try{
                socket = new Socket("10.0.2.2", 5050);
                PrintWriter outToServer = new PrintWriter(
                        new OutputStreamWriter(socket.getOutputStream()));

                outToServer.write(params[0]);
                outToServer.flush();

            } catch (IOException e){
                if (socket != null) socket.close();
                e.printStackTrace();
            }
        }catch (Exception e){
            this.exception=e;
            return null;
        }
        return null;
    }
}
