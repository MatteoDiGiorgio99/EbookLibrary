package it.unipr.basedidati;
import android.app.AlertDialog;
import android.database.Cursor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Random;



public class MainActivity extends AppCompatActivity {

    EditText editTitolo,editGenere, editTextId;
    Button btnAddData;
    Button btnviewAll;
    Button btnviewUpdate;
    Button btnDelete;
    DatabaseHelper myDb;
    String EbookRepl;
    final int random = new Random().nextInt(1001-50)+50;
    String urlEbook;
    String message;
    int id=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb= new DatabaseHelper(this);
        editTitolo = (EditText)findViewById(R.id.editText_titolo);
        editGenere = (EditText)findViewById(R.id.editText_genere);
        editTextId = (EditText)findViewById((R.id.editText_id));
        btnAddData = (Button) findViewById(R.id.button_add);
        btnviewAll = (Button)findViewById(R.id.button_viewAll);
        btnviewUpdate = (Button)findViewById(R.id.button_update);
        btnDelete= (Button)findViewById(R.id.button_delete);
        AddData();
        viewAll();
        UpdateData();
        DeleteData();

        //new SendMessage().execute("CONNESSO");
    }

    public void DeleteData() {
        btnDelete.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deleteRows = 0;

                        if (TextUtils.isEmpty(editTextId.getText()) == false) {
                            SendMessage query = new SendMessage();
                            message = "Delete," + editTextId.getText().toString();
                            query.execute(message);
                            deleteRows = myDb.deleteData(editTextId.getText().toString());
                        }
                        if (deleteRows > 0) {
                            Toast.makeText(MainActivity.this, "Data Deleted", Toast.LENGTH_LONG).show();
                            editTextId.getText().clear();
                            editGenere.getText().clear();
                            editTitolo.getText().clear();
                        } else {
                            Toast.makeText(MainActivity.this, "Data not Deleted", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }

    public void UpdateData(){
      btnviewUpdate.setOnClickListener(
              new View.OnClickListener(){
                  @Override
                  public void onClick(View v){
                      boolean isUpdate=false;
                      if(TextUtils.isEmpty(editTextId.getText())==false && TextUtils.isEmpty(editTitolo.getText())==false && TextUtils.isEmpty(editGenere.getText())==false)
                      {
                          EbookRepl=editTitolo.getText().toString().replace(" ","_");
                          urlEbook = "www.ebooks."+EbookRepl+".com/url";
                          SendMessage query = new SendMessage();
                          message="Update,"+editTextId.getText().toString()+","+EbookRepl+","+editGenere.getText().toString()+","+random+","+urlEbook;
                          query.execute(message);
                          isUpdate = myDb.updateData(editTextId.getText().toString(),
                                  EbookRepl,
                                  editGenere.getText().toString(),urlEbook,random);
                      }
                      if(isUpdate==true) {
                          Toast.makeText(MainActivity.this, "Data Update", Toast.LENGTH_LONG).show();
                          editTextId.getText().clear();
                          editGenere.getText().clear();
                          editTitolo.getText().clear();
                      }
                      else {
                          Toast.makeText(MainActivity.this,"Data not Updated",Toast.LENGTH_LONG).show();
                      }
                  }
              }
      );
    }

    public void AddData(){
        btnAddData.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v){
                        boolean isInserted=false;
                        if(TextUtils.isEmpty(editTitolo.getText())==false && TextUtils.isEmpty(editGenere.getText())==false)
                        {
                            EbookRepl=editTitolo.getText().toString().replace(" ","_");
                            urlEbook = "www.ebooks."+EbookRepl+".com/url";
                            SendMessage query= new SendMessage();
                            message="Add,"+EbookRepl+","+editGenere.getText().toString()+","+random+","+urlEbook;
                            query.execute(message);
                            isInserted = myDb.insertData(EbookRepl,editGenere.getText().toString(),random,urlEbook);
                        }

                      if(isInserted == true)
                      {
                          Toast.makeText(MainActivity.this,"Data Inserted", Toast.LENGTH_LONG).show();
                          editTextId.getText().clear();
                          editGenere.getText().clear();
                          editTitolo.getText().clear();
                      } else {
                            Toast.makeText(MainActivity.this,"Data not inserted",Toast.LENGTH_LONG).show();
                      }

                    }
                }
        );
    }

    public void viewAll(){
        btnviewAll.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {

                        Cursor res = myDb.getAllData();
                        SendMessage query= new SendMessage();
                        message="View";
                        query.execute(message);

                        if(res.getCount() == 0) {
                            // show message
                            showMessage("Error","Nothing found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("Id :"+ res.getString(0)+"\n");
                            buffer.append("Titolo :"+ res.getString(1)+"\n");
                            buffer.append("Genere :"+ res.getString(2)+"\n");
                            buffer.append("Npagine :"+ res.getString(3)+"\n");
                            buffer.append("Url :"+ res.getString(4)+"\n");
                        }
                        //Show all data
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title, String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}