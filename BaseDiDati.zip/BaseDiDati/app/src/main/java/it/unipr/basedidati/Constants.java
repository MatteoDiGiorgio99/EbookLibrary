package it.unipr.basedidati;

public class Constants {
    public static String nome, cognome;

}
