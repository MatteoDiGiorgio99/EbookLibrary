package it.unipr.basedidati;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import android.content.Intent;
import android.widget.TextView;

public class RegisterClient extends AppCompatActivity {

    EditText editTextNameC,editTextSurnameC,editTextPassword,editTextIndirizzo;
    DatabaseHelper myDb;
    Button btnRegister;
    String message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_client);
        myDb= new DatabaseHelper(this);
        editTextNameC=(EditText)findViewById(R.id.editText_NameC);
        editTextSurnameC=(EditText)findViewById(R.id.editText_SurnameC);
        editTextIndirizzo=(EditText)findViewById(R.id.editText_Indirizzo);
        editTextPassword=(EditText)findViewById(R.id.editText_Password);
        btnRegister=(Button)findViewById(R.id.button_Register);

        AddClient();
    }
    public void AddClient() {
        btnRegister.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean insertclient=false;
                        if(TextUtils.isEmpty(editTextNameC.getText())==false && TextUtils.isEmpty(editTextSurnameC.getText())==false && TextUtils.isEmpty(editTextPassword.getText())==false)
                        {
                            SendMessage query= new SendMessage();
                            message="AddClient,"+editTextNameC.getText().toString()+ "," +editTextSurnameC.getText().toString()+","+editTextPassword.getText().toString()+","+editTextIndirizzo.getText().toString();
                            query.execute(message);
                            insertclient = myDb.insertClient(editTextNameC.getText().toString(),editTextSurnameC.getText().toString(),editTextPassword.getText().toString(),editTextIndirizzo.getText().toString());
                        }
                        if(insertclient == true)
                        {
                            Toast.makeText(RegisterClient.this,"Client Registered", Toast.LENGTH_LONG).show();
                            editTextNameC.getText().clear();
                            editTextSurnameC.getText().clear();
                            editTextPassword.getText().clear();
                            editTextIndirizzo.getText().clear();
                        }
                        else
                        {
                            Toast.makeText(RegisterClient.this,"Client not Registered", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }
}
