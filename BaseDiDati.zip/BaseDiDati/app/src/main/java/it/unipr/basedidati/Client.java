package it.unipr.basedidati;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class Client extends AppCompatActivity {

    DatabaseHelper myDb;
    ListView listEbook;
    Button Rental,ViewCart,back,Preferences;
    TextView label;
    ArrayList<HashMap<String,String>>listcart = new ArrayList<>();
    ArrayList<HashMap<String,String>>list = new ArrayList<>();
    ArrayList<String>listpreferences = new ArrayList<>();
    String message;
    SendMessage query= new SendMessage();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client);
        myDb = new DatabaseHelper(this);
        listEbook=(ListView)findViewById(R.id.listView_Ebooks);
        Rental=(Button)findViewById(R.id.button_Rental);
        ViewCart=(Button)findViewById(R.id.button_ViewCart);
        label=(TextView)findViewById(R.id.textView_ebooksDisp);
        back=(Button)findViewById((R.id.button_back));
        back.setEnabled(false);

        EbooksView(list);

        listEbook.setOnItemClickListener(new AdapterView.OnItemClickListener() {
              @Override
              public void onItemClick(AdapterView<?> adapterView,View view,int i,long l){

                  AlertDialog.Builder builder = new AlertDialog.Builder(Client.this);
                  builder.setTitle("Information");
                  builder.setMessage("You have selected"+adapterView.getItemAtPosition(i));
                  builder.setPositiveButton("Add in the cart", new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                          HashMap<String,String> mapcart = new HashMap<String, String>();
                          mapcart.put("Ebook",adapterView.getItemAtPosition(i).toString());
                          listcart.add(mapcart);
                      }
                  });
                  builder.setNegativeButton("Add this literary genre to your favorites ", new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                          String[] ItemSplit;
                          ItemSplit= adapterView.getItemAtPosition(i).toString().split("[,]");
                          ItemSplit= ItemSplit[1].split("=");
                          ItemSplit= ItemSplit[1].split("[}]");
                          message="Preference,"+ItemSplit[0]+"," + Constants.nome + "," + Constants.cognome;
                          query.execute(message);
                          myDb.SetPreference(ItemSplit[0]);
                      }
                  });
                  builder.show();
              }

        });

        ViewCart();
        RentalEbooks();
    }

    public void RentalEbooks()
    {
        Rental.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Accesso ebooks
                HashMap<String,String> maprental = new HashMap<String, String>();
                String titolo;
                String[] titoloSplit;
                boolean AccessoOk=false;

                for(int i=0; i<listcart.size();i++)
                {
                    maprental=listcart.get(i);
                    titolo = maprental.get("Ebook");
                    titoloSplit=titolo.split("[,]");
                    titoloSplit=titoloSplit[0].split("=");
                    message="Rental,"+titoloSplit[1] + "," + Constants.nome + "," + Constants.cognome;
                    query.execute(message);
                    AccessoOk=myDb.RentalEbook(titoloSplit[1]);
                }
                if(AccessoOk==true)
                {
                    Toast.makeText(Client.this, "Rental confirmed", Toast.LENGTH_LONG).show();
                    listcart.clear();
                }

            }
        });
    }

    public void ViewCart()
    {
        ViewCart.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        list.clear();
                        ArrayAdapter arrayadaptercart = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1,listcart);
                        listEbook.setAdapter(arrayadaptercart);
                        label.setText("Cart");
                        back.setEnabled(true);
                        back.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                label.setText("Ebooks Available");
                                EbooksView(list);
                                back.setEnabled(false);
                            }
                        });
                    }
                }
        );

    }

    public void EbooksView(ArrayList<HashMap<String,String>> list){
        Cursor cursor=myDb.getAllData();
        cursor.moveToFirst();
        while(!cursor.isAfterLast())
        {
            HashMap<String,String> map = new HashMap<String, String>();
            map.put("TITOLO", cursor.getString(1));
            map.put("GENERE",cursor.getString(2));
            list.add(map);
            ArrayAdapter arrayadapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,list);
            listEbook.setAdapter(arrayadapter);
            cursor.moveToNext();
        }

    }
}