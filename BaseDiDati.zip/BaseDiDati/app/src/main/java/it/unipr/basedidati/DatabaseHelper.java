package it.unipr.basedidati;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Date;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME="LocalDB.db";
    public static final String TABLE_EBOOKS="ebooks";
    public static final String TABLE_UTENTI="utenti";
    public static final String TABLE_GENERI="generi";
    public static final String TABLE_PREFERENZE="preferenze";
    public static final String TABLE_ACCESSI="accessi";
    public static final String COL_1="ID";
    public static final String COL_2="TITOLO";
    public static final String COL_3="GENERE";
    public static final String COL_4="NPAGINE";
    public static final String COL_5="URL";
    public static String nomeUtente;
    public static String cognomeUtente;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_EBOOKS +" (ID INTEGER PRIMARY KEY AUTOINCREMENT,TITOLO TEXT,GENERE TEXT,NPAGINE INTEGER,URL TEXT,FOREIGN KEY (GENERE) REFERENCES generi(NOME))");
        db.execSQL("create table " + TABLE_UTENTI +" (ID INTEGER PRIMARY KEY AUTOINCREMENT,NOME TEXT,COGNOME TEXT,PASSWORD TEXT,TIPO TEXT,INDIRIZZO TEXT )");
        db.execSQL("create table " + TABLE_GENERI +" (NOME TEXT PRIMARY KEY)");
        db.execSQL("create table " + TABLE_PREFERENZE +" (ID_CLIENTE INTEGER PRIMARY KEY,NOME_GENERE TEXT, FOREIGN KEY (ID_CLIENTE) REFERENCES utenti(ID),FOREIGN KEY (NOME_GENERE) REFERENCES generi(NOME))");
        db.execSQL("create table " + TABLE_ACCESSI +" (ID INTEGER PRIMARY KEY AUTOINCREMENT,ID_UTENTE INTEGER,ID_EBOOK INTEGER,DATA TEXT,URL TEXT,FOREIGN KEY (ID_UTENTE) REFERENCES utenti(ID),FOREIGN KEY (ID_EBOOK) REFERENCES ebooks(ID))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EBOOKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_UTENTI);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GENERI);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PREFERENZE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACCESSI);
        onCreate(db);
    }
    public boolean insertData(String titolo, String genere, int npagine, String url) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,titolo);
        contentValues.put(COL_3,genere);
        contentValues.put(COL_4,npagine);
        contentValues.put(COL_5,url);
        long result = db.insert(TABLE_EBOOKS,null,contentValues);
        if(result == -1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+ TABLE_EBOOKS, null);
        return res;
    }

    public boolean updateData(String id, String titolo, String genere,String url,int npag){
       SQLiteDatabase db = this.getWritableDatabase();
       ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1,id);
        contentValues.put(COL_2,titolo);
        contentValues.put(COL_3,genere);
        contentValues.put(COL_4,npag);
        contentValues.put(COL_5,url);
       db.update(TABLE_EBOOKS, contentValues,"ID = ?",new String[] { id });
       return true;
    }

    public Integer deleteData(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_EBOOKS,"ID = ?",new String[] {id});
    }

    public boolean ResearchAdmin(String nome,String cognome,String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE_UTENTI + " where NOME = '" + nome + "' and COGNOME = '" + cognome + "' and PASSWORD = '" + password + "' and TIPO = '" + "admin'", null);

        if ( cursor.moveToNext() == false)
        {
            return false;
        }
        else {
            return true;
        }
    }

    public boolean ResearchClient(String nome,String cognome,String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from "+ TABLE_UTENTI + " where NOME = '" + nome + "' and COGNOME = '" + cognome + "' and PASSWORD = '" +password +"' and TIPO = '" + "client'",null);

        if(cursor.moveToNext() == false)
        {
            return false;
        }
        else
        {
            nomeUtente=nome;
            cognomeUtente=cognome;
            return true;
        }
    }

    public boolean insertClient(String nome, String cognome, String password, String indirizzo) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("NOME",nome);
        contentValues.put("COGNOME",cognome);
        contentValues.put("PASSWORD",password);
        contentValues.put("TIPO","client");
        contentValues.put("INDIRIZZO",indirizzo);
        long result = db.insert(TABLE_UTENTI,null,contentValues);
        if(result == -1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public boolean RentalEbook(String titolo){
        SQLiteDatabase db = this.getWritableDatabase();
        String idE,idU,URL;
        Date data = new Date();
        Cursor cursor1 = db.rawQuery("select ID from " + TABLE_EBOOKS + " where TITOLO = '"+titolo+"'", null);
        cursor1.moveToFirst();
        idE=cursor1.getString(0);
        Cursor cursor2 = db.rawQuery("select ID from " + TABLE_UTENTI + " where NOME = '"+nomeUtente+"' and COGNOME='"+cognomeUtente+"'", null);
        cursor2.moveToFirst();
        idU=cursor2.getString(0);
        URL="www.rentalEbook/"+nomeUtente+"."+cognomeUtente+"/"+titolo;
        ContentValues contentValues = new ContentValues();
        contentValues.put("ID_UTENTE",idU);
        contentValues.put("ID_EBOOK",idE);
        contentValues.put("DATA",data.toString());
        contentValues.put("URL",URL);
        long result = db.insert(TABLE_ACCESSI,null,contentValues);
        if(result == -1)
        {
            return false;
        }
        else
        {
            return true;
        }

    }

    public boolean SetPreference(String genere){
        SQLiteDatabase db = this.getWritableDatabase();
        String idU,nomeG;
        Cursor cursor3 = db.rawQuery("select ID from " + TABLE_UTENTI + " where NOME = '"+nomeUtente+"' and COGNOME='"+cognomeUtente+"'", null);
        cursor3.moveToFirst();
        idU=cursor3.getString(0);
        Cursor cursor4 = db.rawQuery("select NOME from " + TABLE_GENERI + " where NOME = '"+genere+"'", null);
        cursor4.moveToFirst();
        nomeG=cursor4.getString(0);
        ContentValues contentValues = new ContentValues();
        contentValues.put("ID_CLIENTE",idU);
        contentValues.put("NOME_GENERE",nomeG);
        long result = db.insert(TABLE_PREFERENZE,null,contentValues);
        if(result == -1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    
}
