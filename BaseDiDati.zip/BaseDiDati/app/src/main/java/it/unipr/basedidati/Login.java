package it.unipr.basedidati;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import android.content.Intent;
import android.widget.TextView;

public class Login extends AppCompatActivity {
    EditText editTextUser,editTextPassword;
    DatabaseHelper myDb;
    Button btnLogin;
    RadioButton rdbAdmin;
    RadioButton rdbClient;
    TextView TextViewSignUp;
    String message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        myDb= new DatabaseHelper(this);
        editTextUser = (EditText)findViewById((R.id.editText_User));
        editTextPassword = (EditText)findViewById((R.id.editText_Pssw));
        TextViewSignUp = (TextView) findViewById((R.id.textView_SingUp));
        btnLogin=(Button) findViewById(R.id.button_Login);
        rdbAdmin=(RadioButton) findViewById(R.id.rdb_Admin);
        rdbClient=(RadioButton) findViewById(R.id.rdb_Client);
        rdbClient.setChecked(true);

        rdbAdmin.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        rdbClient.setChecked(false);
                    }
                }
        );

        rdbClient.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        rdbAdmin.setChecked(false);
                    }
                }
        );

        Login();
        AddClient();

    }

    public void Login(){
        btnLogin.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(rdbAdmin.isChecked()==true)
                        {
                            String[] userA;
                            userA=editTextUser.getText().toString().split("[.]");
                            SendMessage query= new SendMessage();
                            message="Login_Admin,"+userA[0]+ "," +userA[1]+","+editTextPassword.getText().toString();
                            query.execute(message);
                            if(myDb.ResearchAdmin(userA[0],userA[1],editTextPassword.getText().toString()) == true)
                            {
                                Intent intent = new Intent(Login.this, MainActivity.class);
                                startActivity(intent);
                            }
                            else
                            {
                                Toast.makeText(Login.this, "Admin not Registered", Toast.LENGTH_LONG).show();
                            }
                        }
                        if(rdbClient.isChecked()==true)
                        {
                            String[] userC;
                            userC=editTextUser.getText().toString().split("[.]");
                            SendMessage query= new SendMessage();
                            message="Login_Client,"+userC[0]+ "," +userC[1]+","+editTextPassword.getText().toString();
                            query.execute(message);
                            if(myDb.ResearchClient(userC[0],userC[1],editTextPassword.getText().toString()) == true)
                            {
                                Constants.nome = userC[0];
                                Constants.cognome = userC[1];
                                Intent intent = new Intent(Login.this, Client.class);
                                startActivity(intent);
                            }
                            else
                            {
                                Toast.makeText(Login.this, "Client not Registered", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }
        );
    }

    public void AddClient(){
        TextViewSignUp.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(Login.this, RegisterClient.class);
                        startActivity(intent);
                }
                }
        );
    }
}